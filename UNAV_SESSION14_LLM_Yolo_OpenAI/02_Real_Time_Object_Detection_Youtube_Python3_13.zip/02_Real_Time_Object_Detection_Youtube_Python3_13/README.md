# Real Time Object Detection
TL;DR: Python application for read time object detection on video feed.

<img src="https://raw.githubusercontent.com/akash-agni/Real-Time-Object-Detection/main/img1.jpg" width="400">

## Usage
You can install all the used packages using.

1. install requirements:
    ```pip install -r requirements.txt```

2. install yt-dbl dependency: (youtube video downloader)

    ``` python3 -m pip install --force-reinstall https://github.com/yt-dlp/yt-dlp/archive/master.tar.gz```

To parse an URL.

```python3 Object_Detection_YouTube.py <YOUTUBE_VIDEO_URL>```

To parse a local video for humans only. (only human video)

```python3 Human_Detection_Model.py <path/to/local/video.webm> <output_file_name.avi>```

- Recomended URL: https://www.youtube.com/shorts/lWv9A2J68cw
- Recomender URL 2: https://www.youtube.com/watch?v=Mol0lrRBy3g

### NOTES:

if you want to download any video from youtube, please write this command:

```yt-dlp <YOUTUBE_VIDEO_URL>```

example:

```yt-dlp https://www.youtube.com/watch?v=Mol0lrRBy3g```

## Upcoming Features.
<ul>
    <li>Real Time Object Detection using Webcam.</li>
    <li>Flask based REST API to stream parsed video live on web browser</li>
</ul>

:blue_heart: