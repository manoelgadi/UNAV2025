from flask import Flask, render_template
from flask_socketio import SocketIO
import cv2
import numpy as np
import base64
import torch
from ultralytics import YOLO

app = Flask(__name__)
socketio = SocketIO(app)

# Load YOLO model
model = YOLO("yolov5s.pt")
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model.to(device)


# Draw predictions on frame
def plot_boxes(results, frame, conf_thresh=0.25):
    x_shape, y_shape = frame.shape[1], frame.shape[0]

    for r in results:   # results is a list
        boxes = r.boxes  # Boxes object

        for box in boxes:
            conf = float(box.conf[0].cpu().numpy())
            if conf < conf_thresh:
                continue

            cls = int(box.cls[0].cpu().numpy())
            label = model.names[cls]

            # Coordinates are in absolute pixels
            x1, y1, x2, y2 = map(int, box.xyxy[0].cpu().numpy())
            color = (0, 255, 0)

            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(
                frame,
                f"{label} {conf:.2f}",
                (x1, max(y1 - 5, 15)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                color,
                2
            )
    return frame


def predict(frame):
    # Inference
    results = model(frame, verbose=False)
    # Draw
    return plot_boxes(results, frame)


@app.route('/')
def index():
    return render_template('index.html')


@socketio.on('frame')
def handle_frame(data):
    # Decode incoming frame (base64 → numpy image)
    frame = base64.b64decode(data.split(',')[1])
    nparr = np.frombuffer(frame, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # Run YOLO prediction
    img = predict(img)

    # Encode processed frame back to base64
    _, buffer = cv2.imencode('.jpg', img)
    frame_b64 = base64.b64encode(buffer).decode('utf-8')

    # Emit back to client
    socketio.emit('frame', frame_b64)


if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)
