import cv2
import numpy as np
import torch
import yt_dlp as youtube_dl
from time import time
import os
import sys
from ultralytics import YOLO


class ObjectDetection:
    def __init__(self, url, out_file="Labeled_Video.avi"):
        self._URL = url
        self.model = self.load_model()
        self.classes = self.model.names
        self.out_file = out_file
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

    def get_video_from_url(self):
        video_path = 'temp_video.mp4'
        if os.path.exists(video_path):
            print("El video ya está descargado, leyendo desde el archivo.")
            return cv2.VideoCapture(video_path)

        print("Descargando el video...")
        ydl_opts = {
            'format': 'bestvideo[ext=mp4]',
            'outtmpl': video_path,
        }
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            ydl.download([self._URL])

        print("Video descargado, leyendo desde el archivo.")
        return cv2.VideoCapture(video_path)

    def load_model(self):
        model = YOLO("yolov8s.pt")  # Automatically downloads if not present
        return model

    def score_frame(self, frame):
        results = self.model.predict(frame, device=self.device, verbose=False)
        return results

    def plot_boxes(self, results, frame):
        boxes = results[0].boxes
        n = len(boxes)
        for i in range(n):
            x1, y1, x2, y2 = map(int, boxes.xyxy[i])
            conf = boxes.conf[i].item()
            cls_id = int(boxes.cls[i].item())
            if conf >= 0.2:
                label = self.classes[cls_id]
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, f"{label} {int(conf * 100)}%", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        return frame

    def __call__(self):
        player = self.get_video_from_url()
        try:
            assert player.isOpened(), "Failed to open the video stream."
            x_shape = int(player.get(cv2.CAP_PROP_FRAME_WIDTH))
            y_shape = int(player.get(cv2.CAP_PROP_FRAME_HEIGHT))
            four_cc = cv2.VideoWriter_fourcc(*"MJPG")
            out = cv2.VideoWriter(self.out_file, four_cc, 20, (x_shape, y_shape))

            while True:
                start_time = time()
                ret, frame = player.read()
                if not ret:
                    print("Reached end of video or failed to read.")
                    break

                results = self.score_frame(frame)
                frame = self.plot_boxes(results, frame)
                end_time = time()
                fps = 1 / np.round(end_time - start_time, 3)
                print(f"Frames Per Second : {fps}")
                out.write(frame)

        except AssertionError as e:
            print(e)

        finally:
            player.release()
            out.release()
            cv2.destroyAllWindows()


# Create a new object and execute.
link = sys.argv[1]
a = ObjectDetection(link)
a()
